// FileSenderHelper.cs stub
