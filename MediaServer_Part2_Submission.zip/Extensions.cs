// Extensions.cs stub
