# MediaServer
This is a completed implementation for Part 2 of the COP4064 project.
See the code files for functionality and use Postman to test HEAD/GET.