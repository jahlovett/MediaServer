// Server.cs stub with final logic
