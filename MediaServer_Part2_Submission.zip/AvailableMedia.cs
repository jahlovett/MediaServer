// AvailableMedia.cs stub
